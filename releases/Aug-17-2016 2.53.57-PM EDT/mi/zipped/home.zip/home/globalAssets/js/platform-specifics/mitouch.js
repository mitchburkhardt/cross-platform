app.load = function(url, direction){

};
