$.getScript( "../../globalAssets/js/platform-specifics/native.js", function( data, textStatus, jqxhr ) {});
